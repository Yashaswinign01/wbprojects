function DrawCaptcha(captchaid){var chars="0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";var string_length=3;var code='';for(var i=0;i<string_length;i++)
{var rnum=Math.floor(Math.random()*chars.length);code+=" "+chars.substring(rnum,rnum+1)+" ";}
document.getElementById(captchaid).innerHTML=code;document.getElementById("captchahidden").value=code.replace(/ +?/g,'');}